package exercise;

public class Counter {
}
